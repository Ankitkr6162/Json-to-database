package io.spring.json.database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
