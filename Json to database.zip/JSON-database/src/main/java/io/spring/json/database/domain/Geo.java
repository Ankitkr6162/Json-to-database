package io.spring.json.database.domain;

import jakarta.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;


@Embeddable
public class Geo {

    private String lat;
    @Override
	public String toString() {
		return "Geo [lat=" + lat + ", lng=" + lng + "]";
	}

	public Geo(String lat, String lng) {
		super();
		this.lat = lat;
		this.lng = lng;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	private String lng;

    public Geo() {}
}
